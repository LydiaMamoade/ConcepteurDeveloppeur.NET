﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Espace2
{
    partial class D
    {
    }
}
namespace Espace2.Espace3
{
    class E { }
    class A { }
}
namespace Espace2
{
    namespace Espace4
    {
        class F { }
    }
}