﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Espace1
{
    class C { }
}
namespace Espace2
{
    partial class D { }
}