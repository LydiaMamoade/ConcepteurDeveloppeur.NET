﻿using System;
using Espace2.Espace4;
using Autre = Espace2.Espace3;

namespace Espace1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Coucou !");
            F f1 = new F();
            Autre.A a1 = new Autre.A();
        }
    }
    class A { }
    class B { }
}
