﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N1
{
    public enum Statut { NonDefini, TropPetit, TropGrand, Gagne, Perdu }
}
